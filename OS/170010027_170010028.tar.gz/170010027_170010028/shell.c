#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>

char **tokenize(char *line);
long long int cputime(char * str){
  // printf("cputimecalled\n" );
  char **cpu=tokenize(str);
  long long int s=0;
  // printf("%s\n",cpu[0] );
  for(int i=0;i<10;i++){
    long long int a;
    sscanf(cpu[i+1],"%d",&a);
    // printf("%d\n",a );
    s+=a;
    }
    // printf("%d\n",s );
    return s;

}


void checkcpupercentage(char* pid)
{
  // printf("Fun called\n" );
int rc = fork();
if (rc < 0) {
    fprintf(stderr, "fork failed\n");
   exit(1);}
 else if (rc == 0) {

// child (new process)
char str[100];
char str1[100];
strcpy(str,"/proc/");
strcat(str,pid);
strcat(str,"/stat");
// printf("%s",str);
FILE *fptr=fopen(str,"r");
long unsigned int utime_before, stime_before;
fscanf(fptr,"%*d %*s %*c %*d %*d %*d %*d %*d %*u %*lu %*lu %*lu %*lu %lu %lu" ,
&utime_before, &stime_before );
 // printf("%d \n %d",utime_before,stime_before);
fclose(fptr);

FILE *fp=fopen("/proc/stat","r");
fgets(str1,100,fp);
// printf("%s\n",str1 );
long long int total_time_before = cputime(str1);
fclose(fp);
 // printf("%d\n",total_time_before);
sleep(1);
FILE *fptr1=fopen(str,"r");
long unsigned int utime_after, stime_after;
fscanf(fptr1,"%*d %*s %*c %*d %*d %*d %*d %*d %*u %*lu %*lu %*lu %*lu %lu %lu" ,
&utime_after, &stime_after );
fclose(fptr1);
// printf("%d \n %d",utime_after,stime_after);
char *str2[100];
FILE *fp1=fopen("/proc/stat","r");
fgets(str2,100,fp1);
// printf("%s\n",str2 );
long long int total_time_after = cputime(str2);
// printf("%d\n",total_time_after);
fclose(fp1);
float st=100*((stime_after-stime_before)*1.0)/(total_time_after-total_time_before);
float ut=100*((utime_after-utime_before)*1.0)/(total_time_after-total_time_before);
printf("User Mode CPU Percentage: %f",ut);
printf(" %\n");
printf("System Mode CPU Percentage: %f",st );
printf(" %\n");}
else{ wait(rc);
exit(1);}
}

int main()
{
    char input[1024];
    while (1)
    {
        printf("myshell> ");
        memset(input, 0, sizeof(input));
        fgets(input,1024,stdin);
        char **words = tokenize(input);
        /** WRITE YOUR CODE HERE **/
        char* command=words[0];
        char* pid=words[1];
        // printf("%s\n",command );
        // printf("%s\n",pid );

        if (strcmp(words[0],"checkcpupercentage")==0){
          checkcpupercentage(pid);
        }

        else if(strcmp(command,"checkresidentmemory")==0){

        int rc = fork();
        if (rc < 0) {
            fprintf(stderr, "fork failed\n");
           exit(1);}
        else if (rc == 0) {

        char * eargs[]={"ps","-p",pid,"o","rss=",NULL};
        execvp("ps",eargs);

       }
              else{wait(rc);
         // exit(1);
        }
       }
       else if (strcmp(words[0],"listFiles")==0){
         int a;
         open(stdout);
          a=fileno(stdout);
          // dup2(a,stdout);
         close(stdout);
         char* aaa[]={"ls",NULL};
         FILE *f = fopen("files.txt2" , "w") ;
         dup2(fileno(f), a);
        execvp("ls",aaa);
        fclose(f);
        fflush(stdout);
        dup2(fileno(stdout),a);

       }

        else if (strcmp(words[0],"exit")==0){

          exit(9);
        }
        else {printf("Illegal command or arguments\n");}


    }
    return 0;
}


char **tokenize(char *input)
{
    int count = 0;
    char **tokens = (char **) malloc(32 * sizeof(char *));
    char *sch;
    sch = strtok(input, " \t\n");

    while (sch != NULL)
    {
        tokens[count] = sch;
        count++;
        sch = strtok(NULL, " \t\n");
    }

    free(sch);
    tokens[count] = NULL ;
    return tokens;
}
