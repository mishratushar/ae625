#include<stdio.h>
#include<stdlib.h>

struct processes
{
	int arrival_time;
	int burst_time;
	int process_id;
	int turnaround_time;
	int waiting_time;
	int remaining_time;
	int leave_time;
	int no_of_tickets;
};



void sort(struct processes *p ,int np);
void sort_rem(struct processes *p ,int np);
void sort_sf(struct processes *p ,int np);
void sort_burst(struct processes *p ,int np);
void sort_tickets(struct processes *p ,int np);

void fcfs(struct processes *p, int np);
void sjf(struct processes *p, int np);
void stcf(struct processes *p, int np);
void lottery(struct processes *p,int np);
