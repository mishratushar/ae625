This assignment is submitted by:

Tushar Mishra (170010027) and Rajat Gupta(170010028).

To run the code for this assignment first run the make function on the terminal. Then run ./sched. A menu will be displayed as required to give input and select the scheduling algorithm. 

The output for FCFS, SJF will be displayed on the terminal

The scheduling order for lottery scheme and stcf will be stored in a separate file named "Order_for_Lottery_scheduling.txt" and "Order_for_STCF_scheduling.txt" respectively, in the same folder.

The waiting time and turnaround time for each process will be displayed on the terminal along with the average waiting time and the average turnaround time.
