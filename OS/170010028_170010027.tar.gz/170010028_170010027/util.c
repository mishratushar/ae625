#include "sched.h"

void sort(struct processes *p ,int np)
{
  // Sorts processes by arrival time.
  struct processes t;
  for(int i = 0; i < np -1 ;i++){
    for(int j = 0 ;j < np -i-1; j++)
      {
	if(p[j+1].arrival_time < p[j].arrival_time)
	  {
	    t = p[j+1];
	    p[j+1] = p[j];
	    p[j] = t;
	  }
      }
  }
}
void sort_burst(struct processes *p, int np){
  struct processes t;
  for(int i = 0; i < np -1 ;i++){
    for(int j = 0 ;j < np -i-1; j++)
      {
  if(p[j+1].arrival_time < p[j].arrival_time)
    {
      t = p[j+1];
      p[j+1] = p[j];
      p[j] = t;
    }
  else if(p[j+1].arrival_time==p[j].arrival_time){
    if(p[j+1].burst_time < p[j].burst_time)
      {
        t = p[j+1];
        p[j+1] = p[j];
        p[j] = t;
      }

  }
      }
  }
}
void sort_sf(struct processes *p , int np)
{
  struct processes t;
  for(int i=0;i<np-1;i++){
    for(int k=i+1;k<np;k++){
      if(p[k].arrival_time <= p[i].arrival_time+p[i].burst_time){
        if(p[k].burst_time<p[i+1].burst_time){
          t=p[i+1];
          p[i+1]=p[k];
          p[k]=t;
        }
}
  }
}}

void sort_rem(struct processes *p ,int np){
  // Sorts processes by remaining time with highest remaining time first.
  struct processes t;
  for(int i = 0; i < np -1 ;i++)
    {
      for(int j = 0 ;j < np -i-1; j++)
	{
	  if(p[j+1].remaining_time < p[j].remaining_time)
	    {
	      t = p[j+1];
	      p[j+1] = p[j];
	      p[j] = t;
	    }
	}
    }
}

void sort_tickets(struct processes *p ,int np){
  struct processes t;
  for(int i = 0; i < np -1 ;i++){
    for(int j = 0 ;j < np -i-1; j++)
      {
        if(p[j+1].no_of_tickets < p[j].no_of_tickets)
        {
          t = p[j+1];
          p[j+1] = p[j];
          p[j] = t;
        }
      }
  }
}
