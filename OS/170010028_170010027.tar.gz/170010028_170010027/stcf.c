#include "sched.h"
void end1(struct processes w){
  printf("%d,%d,%d,%d,%d\n",
       w.process_id,
       w.arrival_time,
       w.burst_time,
       w.turnaround_time,
       w.waiting_time);
}

void mid1(struct processes w, FILE *fp){

fprintf(fp,"%d,%d,%d,%d,%d\n",
w.process_id,
w.arrival_time,
w.burst_time,
w.remaining_time,
w.waiting_time);
}



void stcf(struct processes *p, int np)
{
  sort(p,np);
  sort_burst(p,np);
  int total_time = 0;
  for(int i = 0;i < np; i++){
    total_time += p[i].burst_time;
    p[i].turnaround_time = 0;
    p[i].waiting_time = -1;
    p[i].remaining_time = p[i].burst_time;
  }
  FILE *fp;
  printf("ProcessId,ArrivalTime,BurstTime,TurnaroundTime,WaitingTime \n");
  fp = fopen("Order_for_STCF_scheduling.txt","w");
  fprintf(fp,"ProcessId,ArrivalTime,BurstTime,RemainingTime,WaitingTime \n");
  struct processes t[np];
  int c=0;
  int a[np];
  // printf("%d\n\n", total_time);
  for(int i = 0; i < total_time; i=i+1){
    c=0;
    for(int k=0; k<np;k++){
      if((p[k].arrival_time <= i)&&(p[k].remaining_time>0)){
        t[c] = p[k];
        a[c] = p[k].process_id;
        c+=1;
      }
    }
        sort_rem(t,c);
        if(t[0].remaining_time>0){
            t[0].remaining_time -=1;}
        if(t[0].waiting_time==-1){
          t[0].waiting_time = i-t[0].arrival_time;}
        if(t[0].remaining_time ==0){
            t[0].turnaround_time = (i+1)-t[0].arrival_time;
            end1(t[0]);
            mid1(t[0],fp);
          }
          else{ mid1(t[0],fp);}



        for(int m=0;m<c;m++){
          for(int n=0;n<np;n++){
            if(t[m].process_id == p[n].process_id){
              p[n]=t[m];
            }
          }
        }

}

  int wait_time=0;
  int turn_time=0;
  for(int m=0;m<np;m++){
    wait_time += p[m].waiting_time;
    turn_time += p[m].turnaround_time;
  }






  float avg_wait = wait_time /(np*1.0);
  float avg_turn = turn_time /(np*1.0);
  printf("Average waiting time : %f \n",avg_wait);
  printf("Average turnaround time : %f \n",avg_turn);
  fclose(fp);
}
