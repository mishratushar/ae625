#include "sched.h"
void end(struct processes w){
  printf("%d,%d,%d,%d,%d\n",
       w.process_id,
       w.arrival_time,
       w.burst_time,
       w.turnaround_time,
       w.waiting_time);
}

void mid(struct processes w, FILE *fp){

fprintf(fp,"%d,%d,%d,%d,%d\n",
w.process_id,
w.arrival_time,
w.burst_time,
w.remaining_time,
w.waiting_time);
}


void lottery(struct processes *p,int np){
  int no_of_tickets = 0;
  int total_time=0;
  int no_of_tickets_active=0;
  FILE *fp;
  printf("ProcessId,ArrivalTime,BurstTime,TurnaroundTime,WaitingTime \n");
  fp = fopen("Order_for_Lottery_Scheduling.txt","w");
  fprintf(fp,"ProcessId,ArrivalTime,BurstTime,RemainingTime,WaitingTime \n");
  for(int i = 0;i < np; i++){
    no_of_tickets += p[i].no_of_tickets;
    total_time += p[i].burst_time;
    p[i].turnaround_time = 0;
    p[i].waiting_time = -1;
    p[i].remaining_time = p[i].burst_time;
  }
  int s,d;
  struct processes t[np];
  int c=0;
  int a[np];
  sort(p,np);
  int z = 1;
  // printf("total_time = ");
  // printf("%d", total_time);
  // printf("\n\n");
  for(int i = 0; i < total_time; i=i+1){
    c=0;
    no_of_tickets_active=0;
    for(int k=0; k<np;k++){
      if((p[k].arrival_time <= i)&&(p[k].remaining_time>0)){
        no_of_tickets_active += p[k].no_of_tickets;
        t[c] = p[k];
        a[c] = k;
        c+=1;
        // printf("active_processes\n");
        // printf("%d\n\n",t[k].process_id);
      }
      else{}}
      // printf("No of tickets active = ");
      // printf("%d", no_of_tickets_active);
      // printf("\n\n");
      s = rand()%no_of_tickets_active;
      d=0;
      // printf("No generated = ");
      // printf("%d", s);
      // printf("\n\n");
      for(int m=0;m<c;m++){
        d += t[m].no_of_tickets;
        t[m].no_of_tickets = d;
      }
      for(int m=0;m<c;m+=1){
        if((s<t[m].no_of_tickets) && ((m==0)||(s>t[m-1].no_of_tickets))){
          if(t[m].remaining_time>0){
            t[m].remaining_time -=1;}
          if(t[m].waiting_time==-1){
            t[m].waiting_time = i-(t[m].arrival_time);}
          if(t[m].remaining_time ==0){
            t[m].turnaround_time = (i+z)-t[m].arrival_time;
            end(t[m]);
            mid(t[m],fp);
          }
          else{ mid(t[m],fp);}
        }

      }
      for(int m=0;m<c;m++){
        t[m].no_of_tickets = p[a[m]].no_of_tickets;
        p[a[m]]=t[m];
      }
      // printf("current_time = ");
      // printf("%d",i);
      // printf("\n\n");

  }
  int wait_time=0;
  int turn_time=0;
  for(int m=0;m<np;m++){
    wait_time += p[m].waiting_time;
    turn_time += p[m].turnaround_time;
  }
  float avg_wait = wait_time /(np*1.0);
  float avg_turn = turn_time /(np*1.0);
  printf("Average waiting time : %f \n",avg_wait);
  printf("Average turnaround time : %f \n",avg_turn);
  fclose(fp);
}
